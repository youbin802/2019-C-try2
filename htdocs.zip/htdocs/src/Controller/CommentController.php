<?php

namespace src\Controller;

use src\App\DB;

class CommentController extends Controller {
    public function create() {
        extract($_POST);

        DB::execute("INSERT INTO `comment`(`content`, `user_idx`, `content_idx`, `date`) VALUES (?,?,?,NOW())",[$content, user()->idx, $content_idx]);

        back('댓글 작성 완료');
    }
    public function update() {
        extract($_POST);

        DB::execute('update comment set content=? where content_idx=?',[$content, $content_idx]);
    
        back('댓글 수정 완료');
    }
    public function delete($comment_idx=0) {
        DB::execute('delete from comment where idx=?',[$comment_idx]);
        back('댓글 삭제 완료');

    }


}