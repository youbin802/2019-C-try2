
    
    <!-- contents -->
    <section id="contents">
        <div class="container">
            <div class="row">
                <div class="main-content">
                    <h1 class="antitle">Top Bloger</h1>

                    <!-- content inner -->
                    <div class="col-md-4"> 
                        <div class="anonymous">
                            <img src="images/anonymous.png" title="anonymous" width="90%">
                            <h3>
                                JHON DOE
                            </h3>
                            <span>
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua.
                            </span>
                        </div>
                    </div>
                    <div class="col-md-4">  
                         <div class="anonymous">
                            <img src="images/anonymous.png" title="anonymous" width="90%">
                            <h3>
                                NIKOLAI
                            </h3>
                            <span>
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua.
                            </span>
                        </div>
                    </div>
                    <div class="col-md-4">  
                        <div class="anonymous">
                            <img src="images/anonymous.png" title="anonymous" width="90%">
                            <h3>
                                BRAD PITT
                            </h3>
                            <span>
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua.
                            </span>
                        </div>
                    </div>
                    <!-- content inner -->

                </div>
            </div>
        </div>
    </section>
    
